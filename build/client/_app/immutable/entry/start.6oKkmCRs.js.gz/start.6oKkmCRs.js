import{a as t}from"../chunks/entry.CJlZKMKd.js";export{t as start};
