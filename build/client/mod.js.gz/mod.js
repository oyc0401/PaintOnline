// import $ from "jquery";

const hello = 'hello!';

console.log(hello);


window.hello = '안녕?';

export {hello};